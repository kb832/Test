package utility;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class BrowserDriver {
    public static WebDriver driver;
    public EdgeOptions options;

    public BrowserDriver(){
        System.setProperty("webdriver.edge.driver", "");
    }

    public void close(){
        driver.close();
    }
}
