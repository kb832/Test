package StepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class LogInSteps {
    WebDriver driver;

    @Given("^User navigates to the login page$")
    public void user_navigates_to_the_login_page() throws Throwable
    {
        System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+ "/src/resources/msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
    }

    @When("^Enter the \"(.*)\" and \"(.*)\"$")
    public void enter_the_Username_and_Password(String Username, String Password) throws Throwable
    {
        driver.findElement(By.id("user-name")).sendKeys(Username);
        driver.findElement(By.id("password")).sendKeys(Password);
        driver.findElement(By.id("login-button")).click();
    }

    @Then("^User view the products$")
    public void user_view_the_products() throws Throwable
    {
        //Assert first element is visible
        Assert.assertTrue(driver.findElement(By.id("inventory_container")).isDisplayed());
        driver.close();
    }

    @Then("^User Unable to log in$")
    public void user_locked_unable_to_log_in() throws Throwable
    {
        Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(), 'Epic sadface: Sorry, this user has been locked out.')]")).isDisplayed());
        driver.close();
    }

}