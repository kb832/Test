package StepDefinition;

import com.google.common.base.Verify;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.junit.rules.Verifier;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.junit.Test;

public class BuyProduct {
    WebDriver driver;

    @Given("^User Logs in$")
    public void user_logs_in() throws Throwable
    {
        System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+ "/src/resources/msedgedriver.exe");
        //Initialize Driver and navigate to SUT
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        //Enter Credentials log in with standard user
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
    }

    @When("^Add product to the cart$")
    public void Add_product_to_the_cart() throws Throwable
    {
        //Add products to cart
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.id("add-to-cart-sauce-labs-fleece-jacket")).click();
        driver.findElement(By.id("shopping_cart_container")).click();
    }

    @Then("^Checkout$")
    public void Checkout() throws Throwable
    {
        //Verify the correct items were added to cart
        driver.findElement(By.id("item_4_title_link")).isDisplayed();
        driver.findElement(By.id("item_5_title_link")).isDisplayed();
        //Remove one item from cart
        driver.findElement(By.id("remove-sauce-labs-fleece-jacket")).click();
        driver.findElement(By.id("checkout")).click();

        //Enter Delivery data
        driver.findElement(By.id("first-name")).sendKeys("Tester");
        driver.findElement(By.id("last-name")).sendKeys("Testing");
        driver.findElement(By.id("postal-code")).sendKeys("77380");
        driver.findElement(By.id("continue")).click();

        //Assert item is displayed in checkout
        Assert.assertEquals(true, driver.findElement(By.id("item_4_title_link")).isDisplayed());
        driver.findElement(By.id("finish")).click();
        //Assert back home button is displayed
        Assert.assertEquals(true, driver.findElement(By.id("back-to-products")).isDisplayed());

        //Close Browser
        driver.close();
    }

}
