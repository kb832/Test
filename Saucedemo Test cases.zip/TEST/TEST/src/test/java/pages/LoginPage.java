package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;


public class LoginPage {
    static WebDriver driver;


    public static String login_user = "user-name";
    public static String password_user = "password";
    public static String login_button = "login-button";


    public static void type_username() {
        driver.findElement(By.id(login_user)).sendKeys("standard_user");
    }
    public static void type_password() {
        driver.findElement(By.id(password_user)).sendKeys("secret_sauce");
    }
    public static void click_login() {
        driver.findElement(By.id(login_button)).click();
    }
}
